"""
aeo_check.py  |  Standout Systems Lab: Get Your Brand Into the AI Answer

What it does: you paste AI answers into a text file, this tells you how often
you show up and which sites the answers are built from.

No installs. No API keys. Python 3 only.

How to use:
  1. Make a file called answers.txt
  2. Paste one AI answer into it, links included.
  3. Type a line with three dashes:  ---
  4. Paste the next answer. Repeat for every run.
  5. Run:   python aeo_check.py answers.txt "teodora.coach, Teodora Szasz"

The words in quotes are the names that count as "you appear". Separate with commas.
"""

import re
import sys
from collections import Counter

# Rough labels for the kind of page behind a link. Add your own patterns.
PAGE_TYPES = [
    ("Reddit", r"reddit\.com"),
    ("Video", r"youtube\.com|youtu\.be|tiktok\.com"),
    ("LinkedIn", r"linkedin\.com"),
    ("Wikipedia", r"wikipedia\.org"),
    ("Newsletter / blog", r"substack\.com|medium\.com|/blog/|/p/"),
    ("Review site", r"g2\.com|capterra|trustpilot|clutch\.co|yelp\."),
    ("Help center", r"help\.|support\.|docs\.|/help/|/faq"),
    ("Comparison", r"/compare|-vs-|/vs/|alternatives"),
    ("Listicle", r"/best-|top-\d+|best.*-202\d"),
    ("Pricing", r"/pricing"),
    ("Service / product page", r"/services?/|/coaching|/product"),
]


def page_type(url):
    for label, pattern in PAGE_TYPES:
        if re.search(pattern, url.lower()):
            return label
    return "Other page"


def honest_range(hits, runs):
    """95% range for a rate measured on a few runs (Wilson). Keeps you honest."""
    if runs == 0:
        return 0.0, 0.0
    z, p = 1.96, hits / runs
    d = 1 + z * z / runs
    center = (p + z * z / (2 * runs)) / d
    margin = z * ((p * (1 - p) / runs + z * z / (4 * runs * runs)) ** 0.5) / d
    return max(0.0, center - margin), min(1.0, center + margin)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    path, names = sys.argv[1], [n.strip() for n in sys.argv[2].split(",") if n.strip()]
    runs = [a for a in open(path, encoding="utf-8").read().split("---") if a.strip()]

    hits, domains, types = 0, Counter(), Counter()
    for i, answer in enumerate(runs, 1):
        mentioned = any(n.lower() in answer.lower() for n in names)
        hits += mentioned
        urls = set(re.findall(r"https?://[^\s\)\]\>\"',]+", answer))
        for u in urls:
            host = re.sub(r"^www\.", "", u.split("/")[2].lower())
            domains[host] += 1
            types[page_type(u)] += 1
        print(f"Run {i:>2}: {'YOU APPEAR' if mentioned else 'not mentioned'}   ({len(urls)} links)")

    lo, hi = honest_range(hits, len(runs))
    print(f"\nRuns checked: {len(runs)}")
    print(f"You appear in: {hits} of {len(runs)} runs ({hits / len(runs):.0%})")
    print(f"Honest range: {lo:.0%} to {hi:.0%}")
    print("\nSites the answers were built from:")
    for d, n in domains.most_common(10):
        print(f"  {n:>3}x  {d}")
    print("\nKinds of pages cited:")
    for t, n in types.most_common():
        print(f"  {n:>3}x  {t}")
    print("\nWrite these two numbers and the top 3 sites in your tracker. "
          "Re-check in two weeks with the same prompts.")


if __name__ == "__main__":
    main()
