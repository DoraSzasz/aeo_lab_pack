# AEO Lab Quickstart

Three files. One command. No installs, no API keys, no subscriptions.
You need Python 3, which is already on your machine if you write Python.

## 1. Collect

Open `prompts_template.txt`. Write your 10 prompts, one per line. Save it as `prompts.txt`.

Run your most important prompt 10 times in ChatGPT. Every run:

- new chat
- memory off (Settings, then Personalization, turn off memory and chat history reference)
- paste the full answer, links included, into `answers.txt`
- type a line with three dashes after each answer

`answers_template.txt` shows the exact shape.

## 2. Score

Put `aeo_check.py` in the same folder as `answers.txt` and run:

    python aeo_check.py answers.txt "YourProduct, yourproduct.com"

The names in quotes are what counts as a mention. Add every alias your
buyers use, separated by commas.

## 3. Read

You get three things:

- **How often you appear**, with an honest 95% range. Ten runs is the minimum
  that gives a usable range. Four runs gives you 15% to 85%, which is nothing.
- **The sites** the answers were built from. This is your target list.
- **The page types** cited. This is what to write next.

Log the appearance rate, the range, and the top three sites in `results.csv`.
Re-run the identical prompts in 14 days. Call it progress only when the new
range clears the old one.

## Files

- `aeo_check.py` - the scorer
- `prompts_template.txt` - the 10 prompt slots
- `answers_template.txt` - the format for pasted answers
- `results.csv` - where your weekly numbers go
